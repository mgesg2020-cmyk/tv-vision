import { HttpError, json, seal, open, safeFetch, upstreamMessage } from "../_lib.js";

const rewrite = async (env, text, base) => {
  const proxy = async (u) => `/api/stream?t=${await seal(env, new URL(u, base).href, 2 * 3600)}`;
  const out = [];
  for (const raw of text.split(/\r?\n/)) {
    const line = raw.trim();
    if (!line) { out.push(raw); continue; }
    if (line.startsWith("#")) {
      const m = [...line.matchAll(/URI="([^"]+)"/g)]; let l = line;
      for (const x of m) l = l.replace(x[0], `URI="${await proxy(x[1])}"`);
      out.push(l);
    } else out.push(await proxy(line));
  }
  return out.join("\n");
};

export async function onRequestGet({ request, env }) {
  try {
    const t = new URL(request.url).searchParams.get("t");
    if (!t) throw new HttpError(400, "Falta o token.");
    const target = await open(env, t);
    const headers = {}; const range = request.headers.get("range"); if (range) headers.range = range;
    const { res, url } = await safeFetch(target, { headers }, env);
    if (!res.ok && res.status !== 206) throw new HttpError(502, upstreamMessage(res.status));
    const ct = res.headers.get("content-type") || "";
    if (/mpegurl/i.test(ct) || /\.m3u8(\?|$)/i.test(url)) {
      const body = await res.text();
      if (!body.startsWith("#EXTM3U")) throw new HttpError(502, "O servidor não devolveu uma playlist HLS válida.");
      return new Response(await rewrite(env, body, url), { headers: { "content-type": "application/vnd.apple.mpegurl", "cache-control": "no-store" } });
    }
    const h = new Headers({ "cache-control": "no-store", "content-type": ct || "application/octet-stream" });
    for (const k of ["content-length", "content-range", "accept-ranges"]) if (res.headers.get(k)) h.set(k, res.headers.get(k));
    return new Response(res.body, { status: res.status, headers: h });
  } catch (e) {
    return json({ error: e instanceof HttpError ? e.message : "Erro interno no backend." }, e instanceof HttpError ? e.status : 500);
  }
}
