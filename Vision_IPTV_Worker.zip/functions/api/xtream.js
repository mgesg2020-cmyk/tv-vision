import { HttpError, json, seal, checkTarget, safeFetch, upstreamMessage } from "../_lib.js";

const ACTIONS = new Set(["", "get_live_categories", "get_vod_categories", "get_series_categories", "get_live_streams", "get_vod_streams", "get_series", "get_series_info", "get_vod_info", "get_short_epg"]);
const NUM = ["category_id", "series_id", "vod_id", "stream_id", "limit"];
const KINDS = new Set(["live", "movie", "series"]);

export async function onRequestPost({ request, env }) {
  try {
    const origin = request.headers.get("origin");
    if (origin && origin !== new URL(request.url).origin) throw new HttpError(403, "Origem não permitida.");
    let b; try { b = await request.json(); } catch { throw new HttpError(400, "Pedido inválido."); }
    const { server, username, password, action = "", params = {} } = b;
    if (!server || !username || !password) throw new HttpError(400, "Preenche servidor, utilizador e palavra-passe.");
    const base = checkTarget(String(server).trim(), env).href.replace(/\/+$/, "");

    // Cria um token cifrado para reproduzir um stream através de /api/stream
    if (action === "play") {
      const { kind, id, ext } = params;
      if (!KINDS.has(kind) || !/^\d+$/.test(String(id)) || !/^[a-z0-9]{2,5}$/i.test(String(ext))) throw new HttpError(400, "Parâmetros de reprodução inválidos.");
      const url = `${base}/${kind}/${encodeURIComponent(username)}/${encodeURIComponent(password)}/${id}.${ext}`;
      return json({ url: `/api/stream?t=${await seal(env, url)}`, ext });
    }

    if (!ACTIONS.has(action)) throw new HttpError(400, "Ação não permitida.");
    const q = new URLSearchParams({ username, password });
    if (action) q.set("action", action);
    for (const k of NUM) if (params[k] != null) { if (!/^\d+$/.test(String(params[k]))) throw new HttpError(400, `Parâmetro ${k} inválido.`); q.set(k, params[k]); }

    const { res } = await safeFetch(`${base}/player_api.php?${q}`, {}, env);
    if (!res.ok) throw new HttpError(502, upstreamMessage(res.status));
    const text = await res.text();
    let data; try { data = JSON.parse(text); } catch { throw new HttpError(502, "O servidor não devolveu JSON (pode ser uma página de bloqueio ou o URL/porta estar errado)."); }
    return json(data);
  } catch (e) {
    return json({ error: e instanceof HttpError ? e.message : "Erro interno no backend." }, e instanceof HttpError ? e.status : 500);
  }
}
