// Utilitários partilhados (ficheiros com "_" não viram rotas no Pages Functions)
const enc = new TextEncoder(), dec = new TextDecoder();
export class HttpError extends Error { constructor(status, msg) { super(msg); this.status = status; } }
export const json = (obj, status = 200) => new Response(JSON.stringify(obj), { status, headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" } });

const b64u = (buf) => { let s = ""; new Uint8Array(buf).forEach(b => s += String.fromCharCode(b)); return btoa(s).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, ""); };
const unb64u = (s) => Uint8Array.from(atob(s.replace(/-/g, "+").replace(/_/g, "/")), c => c.charCodeAt(0));

async function key(env) {
  if (!env.SESSION_SECRET) throw new HttpError(500, "O backend não está configurado: falta a variável SESSION_SECRET no Cloudflare Pages.");
  const h = await crypto.subtle.digest("SHA-256", enc.encode(env.SESSION_SECRET));
  return crypto.subtle.importKey("raw", h, "AES-GCM", false, ["encrypt", "decrypt"]);
}
// Token cifrado e com validade: o URL real (com credenciais) nunca vai para o navegador.
export async function seal(env, url, ttl = 6 * 3600) {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ct = await crypto.subtle.encrypt({ name: "AES-GCM", iv }, await key(env), enc.encode(JSON.stringify({ u: url, e: Date.now() + ttl * 1000 })));
  const out = new Uint8Array(12 + ct.byteLength); out.set(iv); out.set(new Uint8Array(ct), 12);
  return b64u(out);
}
export async function open(env, token) {
  try {
    const raw = unb64u(token);
    const pt = await crypto.subtle.decrypt({ name: "AES-GCM", iv: raw.slice(0, 12) }, await key(env), raw.slice(12));
    const { u, e } = JSON.parse(dec.decode(pt));
    if (Date.now() > e) throw 0;
    return u;
  } catch (e) { if (e instanceof HttpError) throw e; throw new HttpError(403, "Token inválido ou expirado."); }
}

const PRIVATE = /^(127\.|10\.|0\.|169\.254\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.|100\.(6[4-9]|[7-9]\d|1[01]\d|12[0-7])\.)/;
// Valida o destino: só http/https, sem localhost/redes privadas; ALLOWED_HOSTS (opcional) limita a servidores conhecidos.
export function checkTarget(raw, env) {
  let u; try { u = new URL(raw); } catch { throw new HttpError(400, "URL do servidor inválido."); }
  if (!/^https?:$/.test(u.protocol)) throw new HttpError(400, "O URL tem de começar por http:// ou https://.");
  if (u.username || u.password) throw new HttpError(400, "Não coloques credenciais no URL do servidor.");
  const h = u.hostname.toLowerCase();
  if (!env.DEV_ALLOW_PRIVATE && (h === "localhost" || h.endsWith(".local") || h.endsWith(".internal") || h.startsWith("[") || PRIVATE.test(h)))
    throw new HttpError(400, "Endereço de servidor não permitido.");
  if (env.ALLOWED_HOSTS && !env.ALLOWED_HOSTS.split(",").map(s => s.trim().toLowerCase()).includes(h))
    throw new HttpError(403, "Este servidor não está autorizado nesta instalação.");
  return u;
}
// fetch com redirecionamentos revalidados (máx. 3)
export async function safeFetch(url, init, env) {
  let cur = url;
  for (let i = 0; i < 4; i++) {
    checkTarget(cur, env);
    let r;
    try { r = await fetch(cur, { ...init, redirect: "manual", headers: { "user-agent": "VisionIPTV/1.0", ...(init?.headers || {}) } }); }
    catch { throw new HttpError(502, "Não foi possível ligar ao servidor do fornecedor (indisponível, porta bloqueada ou ligação recusada)."); }
    if (r.status >= 300 && r.status < 400 && r.headers.get("location")) { cur = new URL(r.headers.get("location"), cur).href; continue; }
    return { res: r, url: cur };
  }
  throw new HttpError(502, "Demasiados redirecionamentos.");
}
export function upstreamMessage(s) {
  if (s === 511) return "O servidor respondeu HTTP 511 (autenticação de rede exigida). É um bloqueio do fornecedor/rede; confirma com ele se aceita ligações a partir de servidores cloud.";
  if (s === 401 || s === 403) return `O servidor recusou o acesso (HTTP ${s}). Verifica as credenciais ou pergunta ao fornecedor se bloqueia ligações de servidores cloud.`;
  if (s === 404) return "O servidor não encontrou a API (HTTP 404). Verifica o URL e a porta.";
  return `O servidor respondeu com HTTP ${s}.`;
}
