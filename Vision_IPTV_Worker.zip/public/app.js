const $ = (id) => document.getElementById(id);
const state = { server: "", username: "", password: "", section: "live", live: [], movies: [], series: [], favorites: [], account: null };
let installPrompt = null, hls = null;

if ("serviceWorker" in navigator) window.addEventListener("load", () => navigator.serviceWorker.register("./sw.js").catch(() => {}));
window.addEventListener("beforeinstallprompt", e => { e.preventDefault(); installPrompt = e; $("installBtn").hidden = false; });
$("installBtn").addEventListener("click", async () => { if (!installPrompt) return; installPrompt.prompt(); await installPrompt.userChoice; installPrompt = null; $("installBtn").hidden = true; });

// Todos os pedidos passam pelo backend (/api/xtream); a palavra-passe nunca é guardada.
async function api(action, params = {}) {
  let r;
  try { r = await fetch("/api/xtream", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ server: state.server, username: state.username, password: state.password, action, params }) }); }
  catch { throw new Error("Sem ligação ao backend da Vision IPTV. Confirma que a app foi publicada com a pasta functions/."); }
  const d = await r.json().catch(() => null);
  if (!r.ok) throw new Error(d?.error || (r.status === 404 ? "Backend não encontrado: publica o projeto com a pasta functions/ (Git ou Wrangler)." : `Erro ${r.status}.`));
  return d;
}

const favKey = () => `vision:fav:${new URL(state.server).host}:${state.username}`;
const saveFavs = () => { try { localStorage.setItem(favKey(), JSON.stringify(state.favorites)); } catch {} };
try { $("server").value = localStorage.getItem("vision:server") || ""; $("username").value = localStorage.getItem("vision:user") || ""; } catch {}

$("loginForm").addEventListener("submit", async e => {
  e.preventDefault(); const status = $("loginStatus"); status.textContent = "A ligar ao fornecedor…";
  state.server = $("server").value.trim().replace(/\/+$/, ""); state.username = $("username").value.trim(); state.password = $("password").value;
  if (!/^https?:\/\//i.test(state.server)) { status.textContent = "Introduz o endereço completo, incluindo http:// ou https://."; return; }
  try {
    const info = await api("");
    if (Number(info?.user_info?.auth) !== 1) throw new Error("Credenciais inválidas ou conta não autorizada.");
    if (info.user_info.status && info.user_info.status !== "Active") throw new Error(`Conta com estado: ${info.user_info.status}.`);
    state.account = info; status.textContent = "Ligação estabelecida. A carregar biblioteca…";
    const r = await Promise.allSettled([api("get_live_streams"), api("get_vod_streams"), api("get_series")]);
    const arr = i => r[i].status === "fulfilled" && Array.isArray(r[i].value) ? r[i].value : [];
    state.live = arr(0); state.movies = arr(1); state.series = arr(2);
    try { localStorage.setItem("vision:server", state.server); localStorage.setItem("vision:user", state.username); state.favorites = JSON.parse(localStorage.getItem(favKey()) || "[]"); } catch { state.favorites = []; }
    $("password").value = ""; $("loginView").hidden = true; $("appView").hidden = false;
    const exp = Number(info.user_info.exp_date); $("accountInfo").textContent = `${new URL(state.server).host} · ${state.username}${exp ? " · expira " + new Date(exp * 1000).toLocaleDateString("pt-PT") : ""}`;
    render();
  } catch (err) { status.textContent = err.message; }
});

$("logoutBtn").addEventListener("click", () => { stop(); Object.assign(state, { server: "", username: "", password: "", account: null, live: [], movies: [], series: [], favorites: [] }); $("appView").hidden = true; $("playerView").hidden = true; $("loginView").hidden = false; $("loginStatus").textContent = "Sessão terminada."; });
document.querySelectorAll(".tab").forEach(b => b.addEventListener("click", () => { state.section = b.dataset.section; document.querySelectorAll(".tab").forEach(x => x.classList.toggle("active", x === b)); render(); }));
$("searchInput").addEventListener("input", render);

const tag = (arr, k) => arr.map(x => ({ ...x, _kind: k }));
const favId = x => `${x._kind}:${x.stream_id ?? x.series_id}`;
function itemsForSection() {
  if (state.section === "live") return tag(state.live, "live");
  if (state.section === "movies") return tag(state.movies, "movie");
  if (state.section === "series") return tag(state.series, "series");
  return [...tag(state.live, "live"), ...tag(state.movies, "movie"), ...tag(state.series, "series")].filter(x => state.favorites.includes(favId(x)));
}
function render() {
  const q = $("searchInput").value.toLowerCase().trim(), grid = $("contentGrid");
  const all = itemsForSection().filter(x => (x.name || "").toLowerCase().includes(q));
  grid.innerHTML = ""; $("itemCount").textContent = `${all.length} itens`; $("emptyState").hidden = all.length > 0;
  all.slice(0, 300).forEach(x => {
    const tile = document.createElement("article"); tile.className = "tile"; tile.tabIndex = 0;
    const poster = document.createElement("div"); poster.className = "poster";
    const src = x.stream_icon || x.cover;
    if (src && /^https:/i.test(src)) { const img = document.createElement("img"); img.loading = "lazy"; img.referrerPolicy = "no-referrer"; img.src = src; img.alt = ""; img.onerror = () => { img.remove(); poster.textContent = "V"; }; poster.append(img); }
    else poster.textContent = x._kind === "live" ? "▶" : x._kind === "movie" ? "▣" : "▤";
    const title = document.createElement("div"); title.className = "tile-title"; title.textContent = x.name || "Sem título";
    const meta = document.createElement("div"); meta.className = "tile-meta";
    const kind = document.createElement("span"); kind.textContent = x._kind === "live" ? "TV em direto" : x._kind === "movie" ? "Filme" : "Série";
    const fav = document.createElement("button"); fav.className = "fav"; fav.title = "Favorito"; fav.textContent = state.favorites.includes(favId(x)) ? "★" : "☆";
    fav.addEventListener("click", ev => { ev.stopPropagation(); const id = favId(x); state.favorites = state.favorites.includes(id) ? state.favorites.filter(v => v !== id) : [...state.favorites, id]; saveFavs(); render(); });
    meta.append(kind, fav); tile.append(poster, title, meta);
    const go = () => open_(x); tile.addEventListener("click", go); tile.addEventListener("keydown", ev => { if (ev.key === "Enter") go(); });
    grid.append(tile);
  });
}

function stop() { if (hls) { hls.destroy(); hls = null; } const v = $("video"); v.pause(); v.removeAttribute("src"); v.load(); }
const b64 = s => { try { return new TextDecoder().decode(Uint8Array.from(atob(s), c => c.charCodeAt(0))); } catch { return s || ""; } };

async function open_(x) {
  $("appView").hidden = true; $("playerView").hidden = false; $("playerTitle").textContent = x.name || "A reproduzir";
  $("playerMsg").textContent = ""; $("epg").innerHTML = ""; $("episodes").innerHTML = ""; stop();
  try {
    if (x._kind === "series") return await showSeries(x);
    if (x._kind === "live") { await playStream("live", x.stream_id, "m3u8"); epg(x); }
    else await playStream("movie", x.stream_id, x.container_extension || "mp4");
  } catch (e) { $("playerMsg").textContent = e.message; }
}
async function playStream(kind, id, ext) {
  $("playerMsg").textContent = "";
  const { url } = await api("play", { kind, id, ext }), v = $("video");
  if (ext === "m3u8" && window.Hls && Hls.isSupported()) {
    hls = new Hls(); hls.loadSource(url); hls.attachMedia(v);
    hls.on(Hls.Events.MANIFEST_PARSED, () => v.play().catch(() => {}));
    hls.on(Hls.Events.ERROR, (_, d) => { if (d.fatal) $("playerMsg").textContent = "Não foi possível reproduzir este canal (o fornecedor pode não oferecer HLS ou recusou o acesso)."; });
  } else {
    v.src = url; v.onerror = () => { $("playerMsg").textContent = `Este formato (${ext}) não é suportado pelo navegador. Tenta outro conteúdo ou outro navegador.`; }; v.play().catch(() => {});
  }
}
async function epg(x) {
  try {
    const d = await api("get_short_epg", { stream_id: x.stream_id, limit: 4 });
    const l = d?.epg_listings || []; if (!l.length) return;
    $("epg").innerHTML = l.map(e => { const t = new Date(e.start_timestamp * 1000).toLocaleTimeString("pt-PT", { hour: "2-digit", minute: "2-digit" }); const el = document.createElement("div"); el.textContent = `${t} — ${b64(e.title)}`; return `<div>${el.innerHTML}</div>`; }).join("");
  } catch {}
}
async function showSeries(x) {
  const d = await api("get_series_info", { series_id: x.series_id }), seasons = d?.episodes || {}, box = $("episodes");
  if (!Object.keys(seasons).length) { $("playerMsg").textContent = "Esta série não tem episódios disponíveis."; return; }
  Object.keys(seasons).sort((a, b) => a - b).forEach(s => {
    const h = document.createElement("h3"); h.textContent = `Temporada ${s}`; const row = document.createElement("div"); row.className = "row";
    seasons[s].forEach(ep => { const b = document.createElement("button"); b.textContent = `${ep.episode_num}. ${ep.title || "Episódio"}`.slice(0, 60); b.onclick = () => { stop(); $("playerTitle").textContent = `${x.name} — T${s}E${ep.episode_num}`; playStream("series", ep.id, ep.container_extension || "mp4").catch(e => $("playerMsg").textContent = e.message); }; row.append(b); });
    box.append(h, row);
  });
}
$("backBtn").addEventListener("click", () => { stop(); $("playerView").hidden = true; $("appView").hidden = false; });
